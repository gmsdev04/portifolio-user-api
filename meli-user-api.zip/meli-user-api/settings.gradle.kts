rootProject.name = "meli-user-api"

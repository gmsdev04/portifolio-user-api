package br.com.mercadolivre.meliuserapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeliUserApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
